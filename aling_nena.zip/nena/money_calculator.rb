class MoneyCalculator

  def initialize(ones, fives, tens, twenties, fifties, hundreds, five_hundreds, thousands)
    @ones=ones.to_i*1
    @fives=fives.to_i*5
    @tens=tens.to_i*10
    @twenties=twenties.to_i*20
    @fifties=fifties.to_i*50
    @hundreds=hundreds.to_i*100
    @five_hundreds=five_hundreds.to_i*500
    @thousands=thousands.to_i*1000 

    @total=@ones+@fives+@tens+@twenties+@fifties+@hundreds+@five_hundreds+@thousands
  end

  def change(presh)
   @change=(@total.to_i)-(presh.to_i)
   remain=@change
  if @change >= 1000
        no_thousands=@change/1000
        remain=@change%1000
    end

    if remain >= 500
        no_fivehundreds=remain/500
        remain=remain%500
    end

    if remain >= 100
        no_hundreds=remain/100
        remain=remain%100
    end

    if remain >= 50
        no_fifties=remain/50
        remain=remain%50
    end

    if remain >= 20
        no_twenties=remain/20
        remain=remain%20
    end

    if remain >= 10
        no_tens=remain/10
        remain=remain%10
    end

    if remain >= 5
        no_fives=remain/5
        remain=remain%5
    end
    if remain >= 1
        no_ones=remain/1
        remain=remain%1
    end
    
    else @change=0
    @money={
        :ones=>no_ones.to_i, 
        :fives=>no_fives.to_i, 
        :tens=>no_tens.to_i, 
        :twenties=>no_twenties.to_i,
        :fifties=>no_fifties.to_i,
        :hundreds=>no_hundreds.to_i,
        :five_hundreds=>no_fivehundreds.to_i,
        :thousands=>no_thousands.to_i,}
    return @money
  end
end